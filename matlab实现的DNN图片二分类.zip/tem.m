clc;
clear;
close all;
trainStruct=dir(fullfile('dataset\train'));
trainFolder=('dataset\train');
trainData=zeros(32,32,10000);
trainLabels=zeros(1,10000);
testStruct=dir(fullfile('dataset\test'));
testFolder=('dataset\test');
testData=zeros(32,32,2000);
testLabels=zeros(1,2000);
for i=3:10002
    trainName=trainStruct(i).name;
    str=strsplit(trainName,'_');
    str1=str{1,4};
    str2=strsplit(str1,'.');
    str3=str2{1,1};
    strNum=str2double(str3);
    train=imread(fullfile(trainFolder,trainName));
    trainDouble=im2double(train);
    trainData(:,:,i-2)=trainDouble;
    trainLabels(:,i-2)=strNum;
end
for k=3:2002
        testName=testStruct(k).name;
    str=strsplit(testName,'_');
    str1=str{1,4};
    str2=strsplit(str1,'.');
    str3=str2{1,1};
    strNum=str2double(str3);
    test=imread(fullfile(testFolder,testName));
    testDouble=im2double(test);
    testData(:,:,k-2)=testDouble;
    testLabels(:,k-2)=strNum;
end
save data.mat trainData trainLabels testData testLabels;
load data.mat;
train_size = 10000;
X_train{1} = reshape(trainData(1: 16, 1: 16, :), [], train_size);
X_train{2} = reshape(trainData(17: 32, 1: 16, :), [], train_size);
X_train{3} = reshape(trainData(17: 32, 17: 32, :), [], train_size);
X_train{4} = reshape(trainData(1: 16, 17: 32, :), [], train_size);
X_train{5} = zeros (0, train_size);
X_train{6} = zeros (0, train_size);
X_train{7} = zeros (0, train_size);
X_train{8} = zeros (0, train_size);
test_size = 2000;
X_test{1} = reshape(testData(1: 16, 1: 16, :), [], test_size);
X_test{2} = reshape(testData(17: 32, 1: 16, :), [], test_size);
X_test{3} = reshape(testData(17: 32, 17: 32, :), [], test_size);
X_test{4} = reshape(testData(1: 16, 17: 32, :), [], test_size);
X_test{5} = zeros (0, test_size);
X_test{6} = zeros (0, test_size);
X_test{7} = zeros (0, test_size);
X_test{8} = zeros (0, test_size);
alpha = 2.40;
max_iter = 300;
mini_batch = 100;
J = [];
Acc = [];
layer_size = [256 32
              256 32
              256 32
              256 32
                0 64
                0 32
                0 16
                0 1];
L = 8;
for l = 1: L - 1
    w{l} = (rand(layer_size(l + 1, 2), sum(layer_size(l, :))) * 2 - 1) * sqrt(6 / (layer_size(l + 1, 2) + sum(layer_size(l, :))));
end
for iter = 1 : max_iter
    ind = randperm(train_size);
    for k = 1 : ceil(train_size / mini_batch)
        a{1} = zeros(layer_size(1, 2), mini_batch);
        for l = 1 : L
            x{l} = X_train{l}(:, ind((k - 1) * mini_batch + 1 : min(k * mini_batch, train_size)));
        end
        y = double(trainLabels( :, ind((k - 1) * mini_batch + 1 : min(k * mini_batch, train_size))));
        for l = 1 : L-2
            [a{l + 1}, z{l + 1}] = fc(w{l}, a{l}, x{l});
        end
        [a{L}, z{L}] = fc2(w{L - 1}, a{L - 1}, x{L - 1});
        J = [J 1/2/mini_batch*sum((a{L}(:)- y(:)).^2)];
        ind_y = y;
        ind_pred = a{L};
        xxj = sum(ind_y == ind_pred) / mini_batch;
        Acc = [Acc xxj];
        delta{L} = (a{L} - y) .* a{L} .* (1 - a{L});
        delta{L - 1} = bc2(w{L - 1}, z{L - 1}, delta{L});
        for l = L - 2 : -1 : 2
            delta{l} = bc(w{l}, z{l}, delta{l + 1});
        end
        for l = 1 : L - 1
            gw = delta{l + 1} * [x{l}; a{l}]' / mini_batch;
            w{l} = w{l} - alpha * gw;
        end
    end
end
save temmodel.mat w layer_size
a{1} = zeros(layer_size(1, 2), train_size);
for l = 1 : L - 2
    [a{l + 1} ,z{l+1}] = fc(w{l}, a{l}, X_train{l});
end
[a{L}, z{L}] = fc2(w{L - 1}, a{L - 1}, x{L - 1});
ind_train = trainLabels;
ind_predtrain= a{L};
counttrain=0;
for j=1:10000
    if abs(ind_predtrain(j)-ind_train(j)<=0.01)
        counttrain=counttrain+1;
    end
end
train_acc = counttrain / train_size;
fprintf('Accuracy on training dataset is %f%%\n', train_acc * 100);
a{1} = zeros(layer_size(1, 2), test_size);
for l = 1 : L - 2
    [a{l + 1} ,z{l+1}]= fc(w{l}, a{l}, X_test{l});
end
[a{L}, z{L}] = fc2(w{L - 1}, a{L - 1}, x{L - 1});
ind_test = testLabels;
ind_pred= a{L};
counttest=0;
for i=1:2000
    if abs(ind_pred(i)-ind_test(i)<=0.01)
        counttest=counttest+1;
    end
end
test_acc = counttest / test_size;
fprintf('Accuracy on testing dataset is %f%%\n', test_acc * 100);
function [a_next, z_next] = fc(w, a, x)
    f = @(s) max(0, s);
    a = [x
         a];
    z_next = w * a;
    a_next = f(z_next);
end
function [a_next,z_next] = fc2(w, a, x)
    f = @(s) 1 ./ (1 + exp(-s));
    a = [x
         a];
     z_next=w*a;
    a_next = f(z_next);
end
function delta = bc(w, z, delta_next)
    f = @(s) max(0, s);
    xxj = size(z, 1);
    delta = w' * delta_next;
    df = [];
    for i = 1 : size(z, 1)
        for j = 1 : size(z, 2)
            if z(i, j) > 0
                df(i, j) = 1;
            else
                df(i, j) = 0;
            end
        end
    end
    delta = delta(1 : xxj, :)  .* df;
end
function delta = bc2(w, z, delta_next)
    f = @(s) 1 ./ (1 + exp(-s)); 
    df = @(s) f(s) .* (1 - f(s)); 
    xxj = size(z, 1);
    delta = w' * delta_next;
    delta = delta(1 : xxj, :)  .* df(z);
end
